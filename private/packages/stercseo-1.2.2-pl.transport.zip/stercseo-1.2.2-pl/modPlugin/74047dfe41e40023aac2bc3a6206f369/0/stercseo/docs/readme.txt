--------------------
SEOTab
--------------------
Version: 1.1.0-pl
Author: Sterc <modx@sterc.nl>

License: GNU GPLv2
--------------------

More info : http://www.stercx.com/modx-extras/