<?php
class cbLayout extends xPDOSimpleObject {}
