<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'c7fee9fd7eb0cb0c2209e67e9a11236b',
      'native_key' => 'core',
      'filename' => 'modNamespace/2796e06686c61c82e437d5432852c4d2.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '88b1e76d2d3dd11d45abe62a3ef2c260',
      'native_key' => 1,
      'filename' => 'modWorkspace/791557ed33eec46e00033f0279911fab.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => 'b05df0d5d14f13c17a48dfe19fa3c5c1',
      'native_key' => 1,
      'filename' => 'modTransportProvider/3509310137da7950a62f053693177ce3.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b8ac31e72c49711ab92428746fbafe97',
      'native_key' => 'topnav',
      'filename' => 'modMenu/6d51a5d3471c443b68dbbf23ac242b44.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e2b3b1e7ff89d37b8684c35b64409ab4',
      'native_key' => 'usernav',
      'filename' => 'modMenu/cfe4a180bec50933d01d8b7d9c81efa9.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '4ccc70c1b90c5bc154be1a1850b914c8',
      'native_key' => 1,
      'filename' => 'modContentType/9781ed306599c5d804bdf2df5cdea870.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'b69265c5d5544823041862ac3177adca',
      'native_key' => 2,
      'filename' => 'modContentType/984560e5af0b31b4042121516add6261.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'b30062f25dc259999a89e603029cddd5',
      'native_key' => 3,
      'filename' => 'modContentType/8dcdf79bf9471155f3fdf62b34fa0ba6.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'b9ccb12dd29e3ae867ec4cbfa14cfdc1',
      'native_key' => 4,
      'filename' => 'modContentType/b384c9080fbe1fdf6ab6d2b6373b58fd.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'a74a826c75a8ddf93c747efddc1f4920',
      'native_key' => 5,
      'filename' => 'modContentType/0e0f8d1d1611482cc853d7c031f8b12a.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'e8bf1fdf7366fa73d6eba6a40279f7bc',
      'native_key' => 6,
      'filename' => 'modContentType/e7188ebb71ccbbfce8cf1b6689576e77.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '1ebb51b93456f317ad3a894531bacf01',
      'native_key' => 7,
      'filename' => 'modContentType/01a6af4f84be8c9f453d1656880f884c.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '1a393068ee6bbf5a0da51c355cd3f527',
      'native_key' => 8,
      'filename' => 'modContentType/c5576e5d3d93eede553d04f459e758de.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'c6d905d4fd8b44d189eab64b947f5df2',
      'native_key' => NULL,
      'filename' => 'modClassMap/fba85e5a953a7ed8c1bec8a6f3a69058.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '79ba9c575689919f9e451ff1be205142',
      'native_key' => NULL,
      'filename' => 'modClassMap/3e8bd55bca07643efa793af7e1edfa29.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '8698a2dfef08c049a53d9446ca32f927',
      'native_key' => NULL,
      'filename' => 'modClassMap/4c236e973a115b3d46bdd4aaf9571518.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '9e81225a5d47846a2d563ea621addc24',
      'native_key' => NULL,
      'filename' => 'modClassMap/8589ba27b47d585bc34867d7cbcf7591.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'fd581896696c968634a0ff3aa765032a',
      'native_key' => NULL,
      'filename' => 'modClassMap/2d0d20efa38a6437c1253fe5782ef97d.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'c2c33751c507970e404393976d11b836',
      'native_key' => NULL,
      'filename' => 'modClassMap/784132598426ef0074bcff1af1464032.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '8acd8949454ce6bddc92bd2ea5696617',
      'native_key' => NULL,
      'filename' => 'modClassMap/aa380214e847be5a9d1b436a9203cb54.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'b28533bad00950868a53916f93105eff',
      'native_key' => NULL,
      'filename' => 'modClassMap/06b8caaa724af81806e79edb9c053c23.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'e81a3f3b38b0e89d89e5d1b7dd5a9f31',
      'native_key' => NULL,
      'filename' => 'modClassMap/48c68928be8e537543af063cf99ac5d3.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ba3ea05054fda43615623c9030e3ea92',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/6562ccd4082df32863c83317efd01950.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '36572d53042f561a916b682a0ec46e72',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/e10a626746e263d620036b055d8a5b5f.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '609bbc956f7dffa9f04b2a5b6614f30e',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/a84fd313b3bcd75fd350b61a3c6f4b48.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '35556b665dc9dcfeca7fc03488ea7961',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/0ade531ce6e1a41677279fcff19216ee.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bc6d5a8ef8959deaa5a054f58a51a4c5',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/22a96b684226edd4a3acc3af0979fce0.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd6c914d2fbdf835099fff22649383d58',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/518f0958cb07d9b7f8c2ab5e69469818.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '47425ccb163f32e7be4738393b7dde1a',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/c0e7d171658cb7ad35132edbc7a8f0e5.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0b1bcbc8fe90c15a65544164c65a3fc8',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/c8e816031cc5cf7ca4c5da3024636608.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e3a7f1b1810c582e4b6f8face84db869',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/c01177de68c108fdc84cbb9225b09115.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02e277db8b92fc4f0f97ac07d6982b3a',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/971b45751fda073e202585ae332658b7.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af255b590d4f676f0684e2c8be0bbc93',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/a1ee1665a3281e0cba2f5436736798ed.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5b5974e5d81557b2b92e3aac59029441',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/be358aac0b8d3f7b9ae0ed4bf955f52e.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9f466a6027f7af77b669b65f7c0edac0',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/07138bdb43f1a16dda1c126fbca25fba.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5bd9ac9ea3ac11d2a6c5f82337006ad1',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/aaafa5c50d38814d5de1b89b175c40cf.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f29e7f90aeaaa57345b108e4a74a0389',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/02748d419c091dc12bef9c66c84d114d.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f97d4f083a0cb5ef729230348cb760e7',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/a5482bf5ba49068ad9e280a15b7f9a9f.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '426e4adcd3f42c600facb7a5622fcefe',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/0f91f38542e37e96d9d6ca7e86799551.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7fd24c49d4590847f412b68301d86bcb',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/c3f7f6856f01ac17632b4c214fa5e573.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c67057c56d07a8d92fb4bca6c7431ef2',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/911f2020a36ba24a9415d553d1947ae9.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8ba8f3a484107cda031edb118fb271d7',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/aefa9ef1acca3f652b34bf8eb9423598.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '576297807ab0b0ab272833a05ff1cdc4',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/f34c9c2428b57c8bfb6cc73b82b3c316.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3bf47bda9fe44d3609cf5032f0c11a5c',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/0928a435df41dc9f67a60f176b19afba.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '05e11900b8d65b1a6f8fabdefd00a8d5',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/be732b95b12e0006e73a86423e95d90d.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '83fb7f8321af2393d834b163f114431d',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/8cdbe844c6d330c8413abee99a241c38.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac32b1cddc807151b01db7bc8f21b547',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/d3a5225c8042903ec3a912b17d4e7188.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b70dc07e4ff389f0713cf60bc28e746c',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/a366738e17ffbbbecbc30578bac07586.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cba2adef6d2532dd45c631691e8a8b70',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/71419b346ba2261586bf110833b7e73a.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '407f11b42dcd9a2b9b7942abb0f24646',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/49e8bd3b79ed5709bb1c9acea3f8815e.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e91c38eac1d14a9c97348cdc6539954e',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/25588e7e5310b72e90dd8b8f61c7f7fa.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5b7a3a42cc0a21ad0ab36b65fc4d9ff5',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/b057e6295c153500cb6ed81436c05d01.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5362d8ee443adbcddc4b67866e5136aa',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/b24a6fb8200c0e66a917e8b0de3e9d8e.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e9e00def21526179afa8cf24ab14a3bb',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/7f5969df0c216eefa1ae25ca6377e512.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff4104b6ab4475a826fb81172f8dbb1d',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/85983b20a0488321879c563c045b81d6.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '64278de8eb4d7b2fa5719f3e121f256f',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/8973584919bac728ae6346dfa11d0958.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd1a58ef82f70cc15c704d14f70eb52e5',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/2c95986614ade4df2d60e8506ad4443a.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f75d06935f449efb82b38dd8fd659125',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/e8a3fcb0a4e2afe41f5004cd7b3a3761.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '78a379a3b9f66b654b30c7fb6ab7cd2b',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/ea401d24f84808f577ee739f4d9d9644.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '037a4ec183f3b33e7015e7e42601a148',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/5cb968a9f2b746eb9ac0920191b6dbad.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f0e630e4621eaadd8cd48271af89379c',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/82106a161df604a6430ad45fca28c1cb.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e4b768662b48b6de42acd35381cf0f85',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/afd8011500329e436c15838198c7a939.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0fd87651c0d02a231bd078de6c9f03ea',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/bd1d0f7482e8afcec071790b253032ad.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '702cd1390fed4b9781135daa8790c530',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/3cb27a8dda7c9bd1f6cde873c30c97d5.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e7578b21590b1b88abfb72bf256669f6',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/8bae79cfe7a842be20a8619a3f6efc9f.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '37c9792714dd3e366c61a20348bd6345',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/defef3ed3678bc3e6488db07fe641f70.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '45fa7033745188d53d0a1c4fc959ec0a',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/22510271bd5bca557a70096afdf55acd.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e50a110c53bd2f79bb90cc391ebc8191',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/a1f4b1ed982d01c20e464bddd20f04f3.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6137c38b4a623f60952eb5489cd0f16d',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/cff53c9f4102ccd6114ed1c4e3b76617.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ffa9167a746a79f396764fbd81581a1d',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/ae116101a98eb6b0e62ab1804ee2a546.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '40daebd2c17d845bd9ad3f76f4e8ef56',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/1da47a20f4f6b9441edf0b973777744b.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2b9677501082070ffc7bb3dab7ac9d91',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/f8d1485caf7beb892040a2b5bc5be07f.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'daf6ec82a4df9ef88a152cafbc556d96',
      'native_key' => 'OnUserProfileBeforeSave',
      'filename' => 'modEvent/48d092c96a33534f3001438f9b205c75.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '87ca5fda733e132ec4ad56187728d353',
      'native_key' => 'OnUserProfileSave',
      'filename' => 'modEvent/15d2e98af53bbee225c749315230efc3.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6bd8a11f9630c0ab257725b8d1e5272f',
      'native_key' => 'OnUserProfileBeforeRemove',
      'filename' => 'modEvent/d710bf170d4798bcc71738feb40d45db.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '56a02f7b1d7520120e68b26d55c68d85',
      'native_key' => 'OnUserProfileRemove',
      'filename' => 'modEvent/0d36091db42d4ea87f8ba216284b15ad.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a605ced592f0f9767b380af62448cd83',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/d3f19ac6c29fb5078992e30a3d42adc7.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd2f34832e7f0347e04a4478fa1a53e78',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/53b1370661d8b7de65b23a0aa9f17246.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '43e0ce80d28988b13f429ae395595fd0',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/d01b3568cdc97d2a78c78e64ef92f08c.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8353eae9f5eb6eea2c726397303efca0',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/473a0d39e11b522e94e785df00b71c3c.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fd239e0a1b60f4d54d12ca32b2f30af8',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/c9fdd732095f1f9f7d63ff0204c313ab.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0e25ccd115a3b0d0225a9eb20b641ef8',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/63833e14e1756e60326cc3f41e233ebc.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '110fea39806c0a095d8f23d217f0a85d',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/28f006be995df171d2ccf38df45b86a0.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f802fe819337d4e4340ca2b0d823332e',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/1ce1293bd3f87e260021bf665a3eeefd.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '63645707822dd4cd8a564a720c91497c',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/037a8f803b8704a03946a0473d09a768.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02bf12d24f8805744458f7157f8b1a57',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/b9c0aecad2051c8b0ae906df515c7612.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '404bbc517513523b79b228a2cd1cebce',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/ef13d0463a21039b673e2315f8791d6a.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af38da00f103507f6b6f882ab89ee36d',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/f93390ccb4de3f6b7900254bab1f3600.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '666ec00189049bba49dcf7039d769733',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/f8b55ba6751e3e27f2a0af7186478c37.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf4c063bfc720f8d13921d474881454b',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/5f691d3d19793e5925b68b34780ee03c.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c7061e953fa61873e91b33e20a161251',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/f1fcc66e3181241f81d37aa88cd691f1.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e8cc1e94a36609e339ccdd0d37d4d9eb',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/b9b64d41b1a62796e9fa6b9400e60a1d.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5013d3f47df3b77de859b793ad683a10',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/446b1ac67dd432058a52637562179e42.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c08ebb83471f07747b39eaeac0600c0f',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/f0649838a857338bca8691fdfe46e4ce.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b43c07df3a3e06e13ad13ee088c60106',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/25b39c3138148d3e004cab45a511f097.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '562cc3e5fa4b2e10ba42dd22429edda1',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/a648c8af4a076c1bd1da4fd375f3e394.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '591e6b4162a6b940caf16d0d6fe56f5c',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/cb1f1889585bbbc3d1a0ec8a30edafcd.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e5656e1d2d1c1f490bb76ff85b2d2a8',
      'native_key' => 'OnResourceCacheUpdate',
      'filename' => 'modEvent/805f74d6054367e651ba82e664b00c07.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9ebba1a22830f2fd27cccc794ac38992',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/eac97b23f2fa7908ff3d1a6ea97d1771.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e0c04a9b2e842c031ec5e65f695800e',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/02e4ee82f03a0a6996009fc7c03d8b26.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fef70926bd18400f65b45dc739008b97',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/0af472081a917d0cc459e3da4bed4cbe.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '68089fcf22294236dd216acf3b39bd0a',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/d949054a61f927764c470c12d160fb3e.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6ad85dd16997afc7a8a18b0fd4e1fb79',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/13cd78d5512f7e113e0d36d66751709d.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af82c7bed4f4909f0f869b32fbe6723c',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/f706ee1ca2e15d652a12fcec4f608bfc.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9f2a71eb570f1e3fe5b46fbee0060f78',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/3410b9920921e6180827a4e5ac7c4449.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0294780b0b72de07cb9f99d97b41e345',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/d1ec2d32e52b4b8178b886dd5da72097.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab4226e7230dc1de00416d0e03145e1b',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/8793923d8c82104aa41966532132641b.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1726098baf07af439a1192d3b1e189be',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/ceae76fe8fb6e3143a737427bdb2f3e5.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b75d451b8625f2d2422e457bbecba5e9',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/952025ec2200c483a42c2047ac26d32d.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a2fc96d4dd341d1944b0b7e2f819f71',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/662ae6d65a7cddf3f4029d33d3671536.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7cbc9aee9fe762f32854fb3d020665b4',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/b042f3f9325177892c6d28dd34bc4e4f.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ee1ce6bc301336d10c96b7079092fcd',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/831feca8e72c23770b806a454589599c.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '562f16e8e2b175c4d7b8ced73e847ac6',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/f6454bc8c5576ba56e921eac9eef0f4c.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '85e882ddd7651ef595999d0de88924f2',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/bedc9843a6c7ecdf333ecf2d6fe87ff9.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e8de9d17649de9fc30b0d2c4ad62334',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/bd8c180191893d4af62f241b9aab8230.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd28ac06e86234d53213b11c05e1a775a',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/fb93c04ae2e23d40c09ccfb96edefa34.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0a448b3a196b31d0f5a938ec6e6c4e23',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/576f8f42770aed110872511b663b34bf.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0e2ee8d977bda8df907399002466027a',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/6b189e2abff262bae9855c85738ce1a2.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f599ac58c60780b3ffb59d483d2d1b0e',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/72ff770e4fdff7ff01a83400d620e09c.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '51ace19a7ea7e964bb2f60d70c21ae9c',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/14d9ee53611208894af962643385bb73.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f2f4c47b3105386068e35071d01d567d',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/dcc1008cd87c4c6a522126dabbfe44e7.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2a886203071e7b2b1d0a7398fbc13f76',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/67a3435869ecd6da3c87b0994a678966.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd9c2a79a9ecc2eb19eb613c18492972f',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/75928ec9569dae979e7c0ded2af4362a.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bd00004e35eb0986a4ce0c680dee8e59',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/c197590bc454a11aeccfd818b572e8e6.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7fb68cbb448dae8106b5befa5f04de3c',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/9774240ca9a2ac06eb5211bb2716df45.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e34da5cb0903b6d7c760a7a062cb7e85',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/766081654d537187ed11cb4df0149cea.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c70e063defa00cf13304cb166e94b9c4',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/03586e37f523074a1df35ca35a3b7351.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '84847dc9584cc5670b35c952277905e9',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/6bbeecac563b22d0994a43b395136488.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a8aedeca2cae442420d17f4df96f587b',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/08b5cb0c3898cf5f5fd912b97d9a4bba.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5f01518e6f985637805cbaae18fd38ee',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/868f4348fcd6d13a3d854bc95cdd0c73.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e71231db16be2beede469d32f700fd34',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/ce0afda3e87368a94f5bf27b326d8bfa.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a03452bcb2f1cb8503c275b96d8752c4',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/d731f563be4aa3386e2f555cd5e19cec.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0e45e63d3cfbebd48beea1e28ab219e6',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/687aa0ead7b735b00e2cc8c0b0505bd8.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '18b8017f1fe93ca9f233d24367001c7a',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/eec510473361df7d105c2b767a927790.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '05069a19ed786ca84ed10f877851a6e2',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/2b69cc88585fd69ed86a797cc58c28e6.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '38644555140075e4624ef07d0e19bdd3',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/0febf9ea185dc35d4f35533223eb5197.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a68d69ea0f0765233da0cda37620067',
      'native_key' => 'OnBeforeRegisterClientScripts',
      'filename' => 'modEvent/505e98651598024e91554512e36743ac.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7bf385d5dbcfefd7fa91d4ee33890549',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/eb635d8566cdb06d9dd2a7971af56df5.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a7a56241d6fa88a01083b5692e968b7a',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/2e0dea20e731095039a2328180a781e0.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a8f27e178570e7810789027591e13e62',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/940abafd447d36e034ae96b3544f788f.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ba2aeaa9a5738065285c273668d74881',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/80c3dbff6b8c919b2108da01175ef25a.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '399e68eb9ad9457a5eef192e59baa57f',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/c75699dc6901a4cc044ab37c19777664.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0ba706b809912af99f164df3aaa3803a',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/ce1da4a9ce801ffca39c882fe67efaca.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c3a9d62007253f93b5c8a7a660fde12',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/6be94c4e7286e93601ff3ca806e77369.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd0c43a73d69b683b3e260f4d51c8e93d',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/0d28e46954ab0d81686aabdcf22f5477.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c5871dc0bdd8715b5a54fc74ac9cd9e5',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/08d7a85c66c6dab08dc4cbe898fd4a76.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fc2262d79e442b0e50bdeb50f9b26fcd',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/65028a9684336835f012ae1a3e67b277.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7a96cb17669aa5d3ccfc9be72a3ce896',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/1807f9be6ebe04d88de15c8d63537ea3.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '12aa602a48be384acc807e584649e857',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/38c29ab93366e2fb1b3f697dd5f6160d.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f2fb451800c4a660fedce9a810834533',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/29f3a683a7646f1819537af418767d00.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6d15ff8bd2db642e7a22b5f99f7adb05',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/7fdf2c68a16492159bfbdb568663216d.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '260d0373cf8b0cc074581dc4ae978551',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/6bc36bc688b73489a0b204fad91f328b.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9eeb848638482caabd45902a60344203',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/e00fbdb56c509016aee7ecfde9e7ae39.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be302815c8544967a07c207f307f6dc2',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/c7db84c40a1ca5805f7b810ae17d13fe.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5e09a1ac299633774740756059afc896',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/93a7f0037849c1fa2694a01d1b43d82a.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ddfe7030adf804076895249f0daf0c2f',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/ef5d0646bd8e77baa5ac641bca59e2ce.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd6d86b2c33eb973aff9b554fd0b85206',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/4877a9422e6c251769441beea8813d8b.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5080cd32732d1f37c46e9ea7f96bebaf',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/a3c9768b25e65b0a18700df0ec670525.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '53e446e47bfbd028d7cd3b69190aecf7',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/3ea641f6b8d3539d7dc0df1c624e1312.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd56a99394f89b33e65c0e4974ae987f9',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/8ae87e4ebcda02575a51043505d06eca.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7eb7eca9b825034ec71333d7555cd7e1',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/0707b63d071517480116b6371eaf35d6.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a71809774660a21a1c4ba46787ac497b',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/d7aa7c2659b666c5e2b70318b02075bd.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9362fbf8657d8ac29372433f1f79086c',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/3718c5808cbade6fc7dbc30272f78e89.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff509f37e3d99e3a53f91fec46061b86',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/c0d9f583d1b59fad7660f33441614ec1.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bab73290e93f104d5453191803e1f72b',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/510838e891093e6e7aa15fbc4f5d9da4.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '56e713093ec76a1cd75db4e9676ae89b',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/c086cd61d44d97f2fab62c667f01988e.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '30d5b36203fb0726892796c6712f43ad',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/f839520b18018caad0358cdd2664658c.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'efef5eec25caa2d9ecc3a4de90740fbe',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/7df863c447ce14d860cfbbb9794ca489.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '97fe29b648ac0492eb89e554e68ead68',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/91b0a38577df6af2066bf25c478c1a19.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a59320320ba8f377774fb38a2d7d0539',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/843d1e2463ac5a6e00d30f90a8eb10d4.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa82c3e3ab780154f55929c9b35cabe9',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/e3db04946a36a080fd9150fa52911793.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '36be6e354a3e582fed8e25c515f317db',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/2eac547dcf64f9eb5508c3ce68ad6b72.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e4623ea0f4240deb75afd45d964856b',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/5367aea49cc85425c98176c07ff1d899.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '19e44d2ec623ecc9cb71fc04a2701032',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/c45d7b9f54fef27440245ce866ba3049.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c891ad798058c82dab332a4e3ad4a93',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/ca429571b43bb9e3bb95c85dd297a2f1.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '43d37103ad6e101ddc7a3b9d0b9c5694',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/fd8ec9e580f344ba37cf1e40512cac28.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed53ac8055d2f748ffdcd8067aead937',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/95fa6f2e927dada649f6da6d7a08512f.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '83d215d8679c1a10653f05e773772ae6',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/c4684aa8a25c264acdb2641c1f276968.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef42229d7113d82da1540d4ba03004f5',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/7320741a0f6019ea18046eb80dc9cb3b.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f33c557b677da92f499429313f7842fd',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/128427e7c0e681611ff22506aec001f4.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed3412c718e10273619acba24dbb4f38',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/0d36243b6e69fff66b9101929b0baf5d.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f542697740b089f5642a640e1710c6c4',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/d4e9ab242761605614bb74e64b94ad3f.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '58854cbb5a7c1df4cf06fc954fa4a6ed',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/430bca3d6d1534ed928e2712b6fc5066.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c64fc5ec3cf17796f988480d2cccf028',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/b326db5fb0cc6634b80308a0aef2bda2.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0811307b440d995dbab81329c3c06c24',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/c52c51b72063525e325c6b0e12a44d84.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '46d3fcdc01266187e83ee84cdff98256',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/634fc6c12816f090a390d6da2d9105a4.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '06dc3f26cca09395c05c26dc88e27d6c',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/894cc6761b239697cf35393ee18a86e1.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e9ed4c36d08d3ef64a0ec7ca624f537c',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/9297135bc88b50ae1bce36ee203908fb.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8d2201a86457ba39a94cd07aff236a4c',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/bf12947c9651ec4f5070ca05a1fdadf9.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1b3b81ac670bc71fea3a9e084358c606',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/ad528eb24f99ef5e02bb3b06464799fa.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac4bc6022e6eb41232687094e75d7022',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/321709839f96209b5d15b8070ca7956c.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd4c2625b34314738cb2052928da333b9',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/8c96b1f0253bc46235901d6d4f41286b.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c8fe5a79d158d209fee40abb1801bfd0',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/17e5f95d8d91efed08daadea1754a93d.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a276fef582a5c5e3bd942740f455263',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/8960afdf422409618a0f719874026481.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1fa68f1a5638f481ec3e134e568176b0',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/f5a9916042a06b1d7f7dd279d1e856e7.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2b9a9667a95b14004090e853740af23c',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/23dcf7f9e8a6050b3a39cc25b0e63989.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '661f2d3d807192df9dc5bcc8b21c9529',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/5da19b0ee1e424e92016a4a24d455060.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '06a132a415a8e8a39e8b7192ceb4d1e3',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/59708e5b7f3217732457168d09e42595.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3d7b8beeb44d8790cacf709d2f44f82b',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/99ff9c2e70a076351c59fcd93a451bfb.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f1604af2d65d2f411462c8803affd519',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/9a2ba2d897e71eaa37a8b30f756475a2.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bdb0968bc85741a397f256a916e9192a',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/c79e972f7ba3bcf8166643915269a079.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be4aab1210a6fb0b66174d2c748d1dde',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/bb679c8c07c2b2fd91aebb8d249f2b5a.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fd5417a0eb34162205559b4f289ebe9a',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/51d71219bdc673b6307fcdddcdfe4652.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '581af11829efca33759847d07a463f2a',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/c11bf08fda8303c183a6110ca506596b.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '732f0fe8374826a516b1eac9f237805a',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/8b3b27e1e4f79346012c84005405e281.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd86ad1c1a53e9b71959f11cd0da0fa07',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/8a13f832ba28d6cf8db76077568662ab.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0dbe470da8db2b7a3191411bf82db3c4',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/aed98962bb96cb91705acfc4bc4f3a03.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '08f098570e0180bbc49d7b02f19a6e24',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/212f49b9b5b28f6a4a931c1ef39ee0bf.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '421b392f04231547f3eb9241b59a753b',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/bfa47ab1e0e32c009f0fde2a76505ab3.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '091ecfbc9dfd8a734aec55129b284346',
      'native_key' => 'OnPackageInstall',
      'filename' => 'modEvent/47de694daefb08729fe24b9adc81018d.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be9c6212601249c857d28dd799a92d49',
      'native_key' => 'OnPackageUninstall',
      'filename' => 'modEvent/baaeccac81700cb00f6b5df1aeb00335.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '70dd96b5376863b8162d2f1f51600052',
      'native_key' => 'OnPackageRemove',
      'filename' => 'modEvent/f962b2da2f69cb8003134c892aec46c0.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33570fcbc3c066cccbdb26e5dac269df',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/ae5c5ecf3d85374422b06c49227a75fe.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2813350e33920d5d42a9525126b507b',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/7048fbfa58928e7aac98df3c4bd990b5.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4295e89a74ced7f389e0973be825f84b',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/bcbf5db8572ce6a1333e5a25d93a5e01.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc7c5188594f0ba81df939bc69657d91',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/059652ce74d2f03d72cea411208b6594.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83d76ee13454f87fdb2d865249025a63',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/9e7b2e9b5153badc194feb062cd8ca0b.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87b011bb02c505367954163e8b24b393',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/07d5244e834f476a88fde9ed1b78d0f8.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1493f0ff54dd13f79eebdb4c93290a40',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/c3fa02a3c24075c9025b402bac6fc058.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2058ba9f0753efa9a3106b0059c8f8f',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/e87b97ca304fec572315502ca6d6268b.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dab688245563a5873698220f98066e12',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/b9f05de2ac8a762762a1a48c61633252.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0023d1b417819fbf46963e4560bf316',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/ec79c2c8ebe297f089ebe0046c1ca6b1.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6a9a6a8cec40c3b27ba4ee695dd22cf',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/7a2d9d8937bfdd876e44a1ec05cc4112.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '94913826fe8beafb1ec9d5bbf2e85eb3',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/f80e0cb405f69781ce5a266c68c40b38.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e60990b1432cc291eb2ef7ece6d44e8d',
      'native_key' => 'automatic_template_assignment',
      'filename' => 'modSystemSetting/54d20111159ca286067fc1f810df6e70.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7c4fa7d850e2159552098baab190a98',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/5118275269dfc429942a6547fa86084a.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5101810ed71fdaf4bd0ce467e336169d',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/db665edb5717076116e0fbc9ed8c6b31.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31edda08ab3f81f48fbe6ebdfd07556f',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/d263bf576ffd91590df86862e0bd59a1.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ea679480467cadb7cc46f0a5539441a',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/a68343f95a3d5d1f6cb85ed7281e7d86.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a1fa03cdbab72d3cf77c1635ec82007',
      'native_key' => 'use_context_resource_table',
      'filename' => 'modSystemSetting/cf869327361ec3014e3a0828e1abaec4.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54d8e99764727223681a1b3afb13e078',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/c5f3679c0ffaf6ee73563892f8f73e09.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '515f366f4822583eefacf146e2deaaf0',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/db5a66c36b3245ba1efb3928c563cff1.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0bdd6d0a034c7cb9e263395156417ee4',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/232576c2e46580779a999334b377412c.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02268055a50584be3bd29a566e8bd3b3',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/2d4e7d5b96eecf1e0b21e14fe9e04bd9.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '969baea25af38c10088aa9357a334459',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/cde73ae4bf753240ed0e7797ac263fb0.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '652b34822801212359b47dc075c2f663',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/bf755c75464ea74419a443dc7491c158.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '980e042a7e191394f06ed2cf3fd9a07e',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/8dc2ea0a0137b073f45a9902c95777a6.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '92e8bf302c4cf341122f1c58e63ffb06',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/e77521351c9a178d23b5a36dd67971a9.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2cad62a44c5866c63c69c1f75c85e0b2',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/6fdd7e01bdea32cd3ed8e18c354f5144.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de42a19b55e9ba222dd51af881598d04',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/f3aae1455dad2da1d42df19319397601.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb4a87f5c0c5921b5cc5ddf6904811f2',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/8c9d5ab50397e7096c0fcc96039b1ed2.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f8393ef6797c779536eb2a44a27fedf',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/04516145ff89b1bb1fdadba17f941979.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5166cb76f4c3a0f15dfd3827d0e7af8b',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/3e1966c28cf52d0273f4f9dd28b2c1cb.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2a97cd248ed91b753c957b5afe10070',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/6fe2d115229d3a0185132948ba25401d.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3c15cfe8cdfceb2a004c8fec4b3d8fa',
      'native_key' => 'cache_resource_clear_partial',
      'filename' => 'modSystemSetting/ac1992ffa9ff8b616832e6a723ad5d72.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f4259d9d2c4c7723e98a56cf115352f',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/495a22fbe77477ffe32345fdc403d7e6.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf8b45315a64a7cc3c569f98277445c4',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/ae7d8bc630a76c97465cd207d7a4e09d.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26a5093c34bb86c076618e98c54e3b1e',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/36d2dc9e2c9172edcfe50b62d255f809.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45ee2b95a7f8865162b9e009dcc9169e',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/280fcc3959f06a9f401488cafb9152da.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ec00eef032c7c95cbf65b39284c10dc',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/df280151bcac0290e9ccf5bec38522f2.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9de48302c9a29f3987b29a68a582934e',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/5000b69a90742b600186aac976ff0c51.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'babeb7335cb5ef17d44921f1954973ed',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/01aca15a795fe0384f5a3ee9b53df854.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd54e318afb235c084eec5bbf5ae37e75',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/4c7206962a6968f13f5c85830b5c076a.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '143e77f07a4b9b77a9b63e96cef83691',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/878224d210b79059af37f6114393d60b.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5fda7620625f448315c4f78464dfd385',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/e1d98e6e04a2a379584d349f46d899c3.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf6a6869f877ce52f46063667a44bd41',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/7e4544a5f600d6f82ca9a4296fd7b701.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '320100710ff6da42b29501b92d7d9ce6',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/f74105e2a69dde57447a7f43eb35f811.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21f3b1be9bf231255ac1636703860549',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/55b914d5199238001b9d00719d482032.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4eb1f877f73e16b4b537abeff5b47faf',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/7f2d176384dc139cb57063af808021b0.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c49b54df5cb310bdbc6d83a3436031d1',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/66a85fba08b30aca79b796d3f868e341.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4ad6582e12c7b4799c1fcb4342ccfe6',
      'native_key' => 'default_media_source_type',
      'filename' => 'modSystemSetting/bc663acafa9b823e55a53a1a97870f53.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0bb9eb9d2a7f613da436ca2fc19d67c',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/6bb95ed1f16532dfd63014b3bd743d87.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4381310f4f001f6cd7cdce68acc82a5b',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/f939b77700f1bfc030b6de6958634756.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82f4072d4fa05fc5bf91d665ea42a82d',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/c55199b8c7ffecc73e1388d104d8ba5b.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e49d9dd7b3c16c64948ec0de975aa31b',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/2b5cb7961e8355ff28186338575506e7.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e71a7a58d5d13bd02ec5c11c2727a34c',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/2232a17c1bcfb96842d5f0b451a3f3e2.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a13d47fd64fe1206714f8ddababafb47',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/ceaadfa8c32e3140a6a97d96c47ac1b2.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fae7a88aced2ecc0c7dc333913ea1d75',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/c128cbb741dc5d6ec9cf4e81b67611c1.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b3f22dbc9938be44d2119254788669f',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/c5b5bdbc248de2ff29a43db1f77026a0.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '872fc3d3cd93b46dececf399982d287c',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/b0d351357f2f9bf152ededb895a4143b.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52940958fe2b18e249eb16a4f6d8c908',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/43b990d786217b61b06bd86a869989b5.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8cc770f72f9ba6a3901c1f929faf1ee1',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/b86aab3c70fdc22b5fd6f11b0f030548.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '968aaa9552e886e0a2128f0f09f9aee5',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/eae85de17635fef543b8d890baa53946.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '136f3ff9e80998238bb2d523a280963b',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/6f57876cb12e826a01b2f8b6ca68bfbc.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4cf11c27f2b2851dffddb60cbd3950fd',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/9dbab20a0a704eb331688edd9314fd36.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46ebf7b6c958aa60e91bc06ba447a867',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/1c300fa94da45f3b217952e38c33bef5.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aec40a6d7a9e00f3e1fc78058b950f1f',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/7c44b584ee37dc4709778d00dc3a88a8.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'adf25b5729bf90446ee6d580b5028ec8',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/51840bbf21ed048218c6526edb33a37b.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bcffe9e7e4d4da4d60424af589a1f170',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/a06322b7b604c78d1feba8af931ad1b1.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a88b617879220d9c6c643f3d91e289b4',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/2250735b3cdaba9adfc864af809b623b.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5991f23c88e86fe86756dc658b73126',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/bae918e5265d6db7e8bbf5364b4e5669.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62f2c73632c90b5fd4875953e2afe87f',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/efeb4672e086126d43205e79ab2aec60.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1957a803f462d324d14f66ecf20e7cc8',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/6ae38bf65f83e517f1e43c1be01936f9.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52fd67038248a724528ac9ac99944cfd',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/740d27ad2a7b945b330dd21d822966ad.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '588e865ed760d4e172e0ac0dc34c6dc0',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/865e6c9df614cbbfd226a8da87096981.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec46bf42abebd2e7dfe70c546d88c507',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/37bc9a9abe80d929ba801d77cb6e7e3e.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0708d5d6108c2014a771b18acba83ef1',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/a4ba2fd71e484336be62ba986dd7257d.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bcf63d387d2c9265baabb5435bc76cdf',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/18705a38bd5aa4a7d968e2847622ea98.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6cae5f4004b69414eabab71747e28ff4',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/0e55e7b4b71eae6ad01920eb076c727e.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d256079de15a4248129520d6a6df794',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/62105a48245c5958b4478799aad94b3e.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cfe3efd05dfee27b2a8dae7551cec5e6',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/a3cc5db832dd00161a31c0aa4d2a969a.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c8d85320dba2174693ec140991d006f',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/cd6537ffc92419b2d8269673011b1f32.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9286bc03263c9b65d5c8bc2981d19feb',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/88c756d918d247e4f911692504179a5e.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c5a4f778a7b67fff734db6d35844058',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/05df76972aaa15dd20bb4574547bb417.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14c7fee41003c4e07690441c8b1ffec3',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/1b1323070e068331e4852269af8964cd.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e4d832a09881afe5f2b1cd6afaa5baa',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/4df6ecd566a46110351038541b609851.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7060cff7a8e3f0005640563b62663f93',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/67d27d3dc329a29496464986cc4a9498.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6d593c6aba3b89af864655decdda83f',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/84caf12d593b4cc3e603db970cd7b770.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f411cf54d906dba5767dc58ca9b3d9e0',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/76bee0972622a59043951ba5e8a1058f.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1f47f5414cb8b05511f05ffcd8215a0',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/7c50b803d97088664db0ac0b39139650.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c30622b0e6a0048997a35c71ec86dba0',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/9c74dbbb93ef34804ef713ad2d233fde.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6535351c72f8de24f9c39acdc0fede3',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/68ccd0a832f76a0f92686682bafef36e.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d543f7a3ff0bdc30694952596cb1dd6',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/97e74294c60984abbbf4c4019f57ed2f.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e78b4886a4554fbe8dec38af77f727f0',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/6fd1a86eae343b2307f08907f44fb8df.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '06ccea1aa7b177ab6b3945659b722376',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/6b4e579c635dee0ccb1fc6487cfc25ef.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7dd54bf7d1aeea32d98bb75f7f3a2cff',
      'native_key' => 'log_deprecated',
      'filename' => 'modSystemSetting/6e80d9dcc6c3ec1c0098075e495bffb3.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a0eb06e1b6bb4e96d2af082c3a29115',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/897a04f295c2418b84efab40b046893e.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1aada5392e3944ec07bb48fc51004c69',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/7e5cb14d5c2c03dba4d1f84231d6cd33.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d175692c7f76ad01c8b08781067aa5f',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/73e3ad6d5f722769064ca74925a77962.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08e16e1db6221a1c02ceaf3682edf52b',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/dce2cc501725882d57ea9fbeefd547c5.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a83436d23be38cfdb4d40c624a408745',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/338fd960b174f406d9360a1a1c19fc68.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6fbcc0d6a1c57de3acd43adc15c7953',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/87ac0908c9cb458721397b8e782cb565.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64804e5c153494fec3a478be0089756d',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/f61fd4e27164d78ba937fda25fb6f1ef.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5e36e9069949034edbcfac2d622c683',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/967aa7ceda122dcc628a4bb83df71359.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '702e50fc2198e27733b263bdd1c903a1',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/16538043e6ae9b8b0bfbdc31af77654a.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16d367aa0a2c0dd027f8b4e48660705c',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/8ff5a43907c9e3f83b2533ecebc061e3.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b11467fd714ee9d68b6a0086540f230',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/263ee920185ff39f2bb55f20136b6026.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a55263215b54014c574ff33a1d485ae2',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/c0909080f7c0730f11d23f5f619c8a56.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e4da059d3032e919a20469aafc31532',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/8c1634c912a9bd468c44817e31964e6b.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e91181af2a9103959500d17d83fae484',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/f1134e19eae5e624fd632098e37ebd61.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1a53260ed7210d2a2030f51897fe5b9',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/e8f1e50462731cd079856ba64a54be51.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79e8ac3de42ed1d4a07ea25afd115f57',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/e7c7bfdad8f5eacd0064b2d74042b77b.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c483b831742c6072b8b32c3f1a217127',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/7e8901eaafd3b67eac24294f6a2ad5aa.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9486eb7fc3e36a7c46b84f70b6c26a27',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/8d2bd9a1105c000deab794534e68b77d.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd1be315d14aff9bd02f2bf81cc55ae3',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/7c2edbf30450318854cd18103d55fc1d.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4122bf1b778849b3fb479405a26bb9da',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/0e1ca138646c22bd76148774a72873f1.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d277a49a73b888d84293f6349a87265',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/97275fafc9df7ebc1e7a77395be0ef03.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '153c06c257e0271f942aca3b4e2232f5',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/d7902928f8cb4b1ca6ead56aa8e1b60e.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '07e1f3b5dfb5abfd3267bf5f0f7b71df',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/b888027ecc41f64e3fe3792a19ad8358.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96c052dcb7c546938c7709cb02ac6464',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/74d215f4cbff7d840423a2ffe77a9566.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0ee9b399948a2b5c25ddc0eb5247a5b',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/0a859f70b8d21559b4e7a10efec55002.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de4171d5e189d98f4056287b4c93893a',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/6d74ec36d875083075cbb32ce1da3bf7.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a13e7d9bdec8b8863cb0a950817bff9',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/4a0077afb7a495db42637419ff12db97.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '11e957f1665db39b186736cb3d3ad471',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/9422824973616d7a96c0b1804ce2f2c5.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd843163c02c8ddbc070c9a5ae22a9d2d',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/ead31b471e29b8271ae21ee5123944ce.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4228b4481723cf7445edba02d19c9787',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/974844ab2b09be69eaef3400822508d1.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c063b3c7bb542f9cd1b82f1cc352958f',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/a7df5772d36018d75f7c872a8a83aa65.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '60a69b82bab907698a3634aca4eaf851',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/89f1c0021cac0269144d99e5fc9e4308.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c414a9dce60b0697054d823026c7ebe7',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/4db26283b0fe803e1faa7de139fbe975.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd64d6929b5266e2f84d616f7178daf5',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/b6527d2b5d62680a1a6116101ca7cd92.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a9187bb8c7f9c0d35f2bb735d14a4ea3',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/439e3731e4bacad65dcd2acdaa7147b3.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b75aaf1b73ee886eb66674f60e92ad2c',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/a119a87e1499ec79ad0384d2092f795e.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5671b18e56d19e8acc2918baa095fe5a',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/43c0c8e2cf0663ee88314e84733e0a78.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8bf88e3943f43e062041a1b83acdcdb3',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/ca500026a9d5f280dbbb9b13133703c1.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d2ae3df232796048a93d364a6f71200',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/d0e07237497835cdd95b935871f91b2a.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d53a8949b1fe4c839a216f13d526c70',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/9333f5e1192c34e8b4db714e651fc090.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8bfd4edee4e01f7c2a3a2bbc96e3993d',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/dd7f2cd3a0b263ba38d12f519ebbe672.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82500fe2c18332b054235de8037c53da',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/81514040e34357aeff1163eee89bb7d2.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '85e371c33a2e4c7444e6b47c83bb9d99',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/ecaeda97d39a4f946ba5ef17c1d452c4.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86b954a0f4bfd99d14b7b448865537a9',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/1b31e2f16cf277c15f48dc183d68d213.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ac98f7b7dd28d735477ba12e30111ab',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/d279a00e1b7d468ebab80628782de942.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2dad1824d37cff3a2bb88cffb88a513',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/554bbd83b0d8f9bc2048b99a80695120.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73efe3bc6d23e1beed53a2781c452242',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/aabec334644f022c9a6d6a2f5ebf913f.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fca215aeb721948429d099e972d61e45',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/04e614df66deeed9e02c4c9cbb3272f9.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7371fef0150871d8635787d491196fa1',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/c34a7be411ede6e14210546b92b50c91.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13a9696767a9a1ad48bb8210079949f1',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/4e05c41553ae3c4b447fea8b511db4c6.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '521db3099c9e47f6f45624d1bc3778ea',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/ad13cbd8cce87dd15aa20bc676fa19e9.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a91cb486b007b9995b5073708a1e757',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/ff1335c36148b1d3501271d6d2d25261.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cdeb51c39ad7395cc59b0205e2df66ea',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/cb36eb64ccc9dd2ce3362fd8b33ebcb7.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0962ab4fe303e4f903ab6c9b0b5601e3',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/78b96225f24f711260582174e0531f95.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e4aed1a0f679af1bc9eafc45d70f12e',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/4b90cebc1f5ccc48e0a902dcfeed3f43.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9053ec80a496a0177c84b652e51bc944',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/045a59352277b5dc8fff8b846261e83e.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bfb2efefb9e532feaf3a8b771fae1231',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/a49ae85a58765363dc2b80e97efd3692.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6df06e396899ceac051d146096de861e',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/8a319708c1b4a76261e83a5b41060e5e.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bbd86b5f4e0ecc08d9814c23389c3fb3',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/1193ff6ae363549deec905ba23288b17.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b68318e1f226a78a0881f3ee29e047c',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/7f4fded342aa1b348ac5123ed1cdf4c4.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '049de9d370ae201b30a3f5abe7d53f47',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/e80631c251794935da84cd0db72b9893.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '929b2ef27fb2e6c9fa90e9a2811730b8',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/8bc809fa426297d24c8a56696eb8c791.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ffc2142e037fb670a80fae4ce0c7412',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/81ae6fb4f68e6de269150532252b4c2a.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3966f5782a5a98c63d0475aa0196b314',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/890c05fa69040c491601e31537e2593c.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8d37bd8f83444b4bb3b9076321d2fd0',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/531ed108b01924d7ef5ef5a4f8b4de2c.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '500794ba752602023eaa31aa784b8a94',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/3172084165669d600a6624aa1a10e77c.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4409ee0ff20e418db8ca166438a2db65',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/b615142f844a046afaf411dd1f12d9c8.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '659d024734945c30608bb4c023851b18',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/022f80df42f193b8630de70d6dd4ef7c.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '807910cf13977a753275974f9886db51',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/28a18c7b4e9365556953e6ca09a6eff5.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d726c46b2759549753f8923106201eb',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/953d1b38d361eda3d8fd1e67708bc66e.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'efd1ac432cd14ffd4f2d24ae68141318',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/3da3cb265b541a2cd113baf19e41b4fa.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa0f1938be731acc9408b9dcdceca043',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/85281e271c32400f797cabb69929997b.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd77a8f79e8952c92c3d7d4b8aaf0e3ed',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/913bbcceba07069373c156cb154b6300.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b03c830e2b24bd2d0a44a81535b9eef',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/d35e6d6a06a656c3476b5fc148bb2ee9.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89410ec5bd2792a846af4f4485caebef',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/549ca46b0d84a0b09fe5b1b3bd1ca085.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '84676a472dd78954e7cc1918fff1e55c',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/17c265d7794b3baea7e98d6d71f68a29.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c875479eae364390755b3daa3f2da22c',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/2feb2e238a9d78e252069f2632ce4c0a.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f3a9cb1683dc642c14814a6cd778e791',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/c15f011fe7c438f78a011424506d5bfe.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83944de0898176d5dd0f6160e610b5f4',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/0268e3bcec9f76e3258ad022125b17f4.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2617501974f308e81f0692ba8621755a',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/1aeb5f470dc66caff0ffffb7461ed383.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '211aa56ba234b9df6bd5e56cf4d91b51',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/51338561c43ec05d1e88bded805461b4.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '490fd4e64ae1f8db3691539ea309fbcc',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/ec0c4b8ab5d5b0653c9e60bd1b557643.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0ded101905557290278f6bc486ced4a',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/0186a7bd8c40076fc251ba775a2c40e7.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54b66dc58334d727699236d8a913d8a0',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/667efa27a3c11996754f6f658d9d5776.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1150e9ce9c6e0c093ae53507766b179b',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/539545924e7cae2e026b218930c3724a.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fcb85cb3183134b327f9892915a93078',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/d93ae7f062d254242be6daa7acc2871c.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '181d5f3c11b8537ce02c7007d04c5c83',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/7afcee25f49038d9fed25760a6ce33df.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e1a2ded8a67edd64b6bb31bb86c190c',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/675d4f2c94958602cb61f3996f105263.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc32e2c465096f41828faef3d0e8db4d',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/e69ab8c833e5b95226d4ba4f97cd708f.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64d98c5e20cade062e91809277b16619',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/79e686725735b9bd0c95e765de4dafe6.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7208313f3f7f0174737cfaae6aa9a03',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/6c3f108a9df5788ae88d774fb85df7c8.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96bf8248fc6d3065f8f02dd022a3f9c2',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/35e79573073b83030446da20737881b2.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b03d4cf898c791f8fc24c01fd4db2b17',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/9e22a183549e47d0affef6eb2cabf4eb.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3533fa80c3b8b7db4284b0ac0e9d6e49',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/b6d833d5fad9d4f2fa7149279c25a740.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c28abcf117b9f0b17c5be7bf9bcd768a',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/f66c21805abd1f72d12865f4544dc33d.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0567109fcdb34c104121cbebcd08959e',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/3944913ff9e5862d42367b851dbca565.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3e054243dcd60a2162cebc1ef698f89',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/4d0599f8ce846393eb2e7a04019af40e.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bbb309cc3ad5dd5cfc655f09a494739f',
      'native_key' => 'static_elements_automate_templates',
      'filename' => 'modSystemSetting/1a3ec1be9447fd8d63aecf90caf7cfa9.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7406117f3abcb70364159b6fbf86b25',
      'native_key' => 'static_elements_automate_tvs',
      'filename' => 'modSystemSetting/8baebec6a132d20f9a6e6dd962e81720.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc95d64ed28b83dad1227916c3682e43',
      'native_key' => 'static_elements_automate_chunks',
      'filename' => 'modSystemSetting/0abc90d49684968d4be3efa9addb37ae.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bef8743da6bd0eb170efd6af74a5c14c',
      'native_key' => 'static_elements_automate_snippets',
      'filename' => 'modSystemSetting/ef3da1c4d28868da245bf3e1483987d1.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8cefe3adf922ead371539c9bdb94c43',
      'native_key' => 'static_elements_automate_plugins',
      'filename' => 'modSystemSetting/5f37cea31a9f8cabe5bb488c9b2ac1f8.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '232c0f5c334726375818c708e01be816',
      'native_key' => 'static_elements_default_mediasource',
      'filename' => 'modSystemSetting/65c8d5f84fb9f6dcf3368f0907fc1bce.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1534908f38b34625e8588574cc36693d',
      'native_key' => 'static_elements_default_category',
      'filename' => 'modSystemSetting/8e93f0ebd95af4564f382acae849ab1a.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '42b0dc4a2831424a3ed2d24512a46ebd',
      'native_key' => 'static_elements_basepath',
      'filename' => 'modSystemSetting/b2c318287180c9d0de21686aa2ddde21.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8da6769dbb4418447b3f84efc9097f14',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/df1a20b73242f5433303b8e1504df932.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6981a0a2face6b75969426d096404c81',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/0689ebd49bcabe17d2241b7970c0659d.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9775ea0d8c7058ce3ce3b0c9cec24b36',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/7088256c939a6e3e00fd81c37b5ce63d.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb72c9e686078e964fa7e0e1cb9bdaa7',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/a1b26ee6bb313b982b762d295cba6a86.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b4189e78a9155cf0ca9dc0ce2b889cf9',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/32a385a50f1c86d3ac2a53d4157ff007.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7112ccab4a2f70ab65b97fcd617e4c5',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/9a442d5cf0c9521dff06dfd5cbc708da.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b6a5da4f15ce66e289469baee06b500',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/ab3d629a21a604fb1736e510e026a235.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd993580fd2251f56303b1d4e58fd7ea8',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/0cea1bfa36f03e7067b28ff89cb45766.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '933cf55a8c123f20a65f144bc6778285',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/78261b1819888004bc405d4624ae7308.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4093b868ef08bbd2e86e5e83ae268aef',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/4564f4f06e4bdff33de0bb7f191b9a64.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37cea412e765c0e93bd292ff4666410d',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/9e7d1920336cbf2a7931ea6ffe7d8a83.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '76bea8a8674f51b8e99001c760bf7f25',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/059bb2cc18f0c3783b46b92d74a445f1.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62c0a801df5bccaccc7d2cfa8a73254f',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/9d8349a016762343a613c84a7349ae81.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1006178545c920ee9d1648822a426f4e',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/ce38ecfb5d8ac12c159525c817a17368.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f461b64efe79ce66256e03a591e6808a',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/535bd1fc08263827ad5db9110af3bdb9.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c885e3dc22b90c59494c6b5ae8ba19f',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/cd3b88e823b9183fc3df39cad5cfd254.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2041a67f7f195d074862cfa99e481235',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/66a704ef44023cb5d84538906c097265.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51304a305e454bba40406fc944e327d8',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/ab2ea7b943939529e6132172c6f74580.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '253cd6cd4607d47747036e91c05d1650',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/ff4e3f0d92d93af34b16f8d49e05c659.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd421d1d85f29600d19668ea078499b57',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/b1cf14245985fa4b5f863e1c82a4178c.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '011272b277c2ee65380f2cbcef931e91',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/47a9c846ba9bfbecc00f9874acc91555.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '32541b20e2dcfa0af8abe7072764a153',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/ab0c4667816adcfda08970392e3a6126.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a6cdaec299d2a59baed6a0cc212bb17',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/c4302509b035311e6b957f1de779e028.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc8cbc6c1671f10b2eab85556f7dd452',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/5eef9bf1b3f1d70cdb2d2b746d368da3.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '95d241377f5fe37c7a3d35f123b82c50',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/1d712eaa9e9c7c04e0371cb1af299889.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0449993d7ebe226ec52ede40ea9d5ba2',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/bbd706718a2d66642a64357259b5247a.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca584078d1daa32d068a30b5eebaee09',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/02f82bbb78c5f54331ce51526091244c.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a56c0dfdae279853ec3e0325065c52f1',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/d830427411883b4c860b460a4e283bb4.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8400e0b79138337f747bd260348849d',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/90c0d48d7f812e937af5e06a72c36919.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5900b5fa5f05a49fef33499ddb66a32a',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/664aec9798bc390487a5171018cd22d0.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'beb79cb30cead1e2deb23de5ba18fc10',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/8a8ce3242c7fd3c7dd0ecdff7cf69fd3.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a537789fc0225ee7b2fd9d8fcc9b5966',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/4299eae27b0cb20c7744d9f24916af0a.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '95a9eedcf238c7e463a20619a75b8dc8',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/40e7a4605f1732f575b967b2a9660f5d.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b7fc4f3e6aa2bc7f93dda7a4b7ab4ed',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/9533b898a3059acb77d291e50714803e.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '11e2603118c0079a3d37db07be17d4ae',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/0f7efb9da32cbc1739757d62fef30070.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27df7e0f232802255c1fb20e60afc68c',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/445e5483b9ae839920c2e4c782019a9b.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51076928daa5d311cb69220f1dafe84e',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/d6e4959b1639f7015f92ffe95143ee17.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b6018577b511057e1afe0dc4314487d',
      'native_key' => 'allow_tv_eval',
      'filename' => 'modSystemSetting/a999055c91bf872b35431fe1c2dac68a.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6469fd200185a9c3f76bcc84fe6eb69',
      'native_key' => 'log_snippet_not_found',
      'filename' => 'modSystemSetting/6fdd083ebfa6bad1de288bc234a0e9c2.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f501877aab5b6048c13f836e3333ec96',
      'native_key' => 'error_log_filename',
      'filename' => 'modSystemSetting/b2249840c63adfd6eddf6a71d543aaee.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55202ee482d00034c3d5a9a7aef7fcc7',
      'native_key' => 'error_log_filepath',
      'filename' => 'modSystemSetting/c4f438614ea067e45cabacbc364efaff.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'f6a2d1ef7a249c2fbfed7ad59b30d93e',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/d6024308794c85fcac877335572b1d66.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '90b3a8e36798b04527d7fd11b38c1ab8',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/3605655c27d87081c3facc15dc74dc64.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '45f867e42c726a13d8f67b032baf2583',
      'native_key' => 1,
      'filename' => 'modUserGroup/a18225112eec87487406ab210f6a9891.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '16c100a5e0bd784a75196ec9037adfed',
      'native_key' => 1,
      'filename' => 'modDashboard/34157dd33fdf2090d7bf897f8de048f6.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '703b5d600023ae9798f8fd6ca49774e0',
      'native_key' => 1,
      'filename' => 'modMediaSource/fafca62920edf82aaffcedcf0033be28.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '93cacc39eefd2ecf7051d32935feac54',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/a456a149276d3e59fcb30f00d9cb5a68.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'f406ad77c00e53c3d5ebdc9744904bb9',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/fcb31ac750608c78e6528c8c2d678784.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'a2f779e5600e71cd04669335aa4bb86b',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/72e5ce186f1e4d48efe1ca44aefc509c.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'd5eec8b6bce086054f11744b82525b45',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/b559e3440304b3c6c6942c8fbd9d80f4.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '1c886dc6734e0cd487573999048bdf4f',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/533c58f54390f528e86f66e125d317ca.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '760964a79ff86d61971ef5f3fc88c107',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/4570c63cee35937dbeba92750ba628c6.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '179d2f86fd7b744f22f2717497c8d69e',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/1e3ad4ae845fbc6afa66b54d8a50a6eb.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'c7b64b7bf9f2e77d71581dea66dde164',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/71b229161981ad60096211a733c3da15.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'ba7373c8c4e2b319587383cb2224045d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/596f781f4596eb0afa0edf3468303951.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'd6907f850be66288071842f7b3076d3d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/15415ee6cc100906f0e2452e26da2c05.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'c93405484be67febcd1245b899d228db',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/bc2c0aea7e42f8b1f16b82f2cd28a825.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '09faee84b6ade1cdfc82b493a9a6b2bf',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/274b30521f91edfcc49bc385e0c6665b.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '02ab183bbd3758ca5a4fedba02216b10',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/ebdb730451ff7e3ed33212c3a1aec063.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '443d4337ec8d2d6f1e9d51e4f445e15e',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/4e48ad1aab22f16222a5d0e849d39190.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '360f91197acf44aca5464b91a6334a31',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/33c5721da45b2828f31cf421cae239e3.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '648f122861502da170c84e8ab58f9258',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/6585b5eee8eceaa827554f49a9b0d372.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '223f0b123b28a8cda9277fc36a3a96f0',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/df2a8467dac134599144f11a93ecc12a.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'a7e2cb6e3ab07c271c7cb10db80752cd',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/1ae4477098ec751a50aa1d720e33f953.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'eaa06e91ef4d9c71c4d6f0de408977ec',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/2d841dab92525f9690bcffdddeb6669b.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '749d36132e977da15bca8cd38eaf789d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/bd40e869b1810f01132ce3e97ee3505b.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1257551695539ce428c361294b2f8c13',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/91889a56515fcadc357a3eaec22a114f.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'e3ee8750290671bbe02c43be6bafb20a',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/d78b3c45c40e4d3d59554d7ddca4032f.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '2f4bbebc9dc687a642e06a0605d7b88a',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/64f26d75b8551bd9853b76522896104d.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '8c86bb90869637150915ba0a9effd7dd',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/0bc87c9e4bfc1e63052cb156d683ed16.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'aa4c58a0e1901d5a17b576ccc794eeb4',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/e29c9a62254321adddc3e243e027ffd7.vehicle',
    ),
    482 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '26e20f41c371abc4886d98b56881cdcf',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/096ccf91e75e01f302cca3454dee0681.vehicle',
    ),
    483 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '3bf89b14fd6badfc1ba851280c459b43',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/9f4acc5da4ff5b37ed16d500dff0f72a.vehicle',
    ),
    484 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'da703dd7cbf81b0704f522c15c75910e',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/619f10face1cee6a63a764bf0dc388e1.vehicle',
    ),
    485 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '6f17650cee8acc03179e08829cf09838',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/244f182eb7d3517556df1537d5bd075b.vehicle',
    ),
    486 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '6aaff4951981524b2744307771e26cb3',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/89bcc100be320aee0927a4988a1a0f78.vehicle',
    ),
    487 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '5efbad232653f6a3a68220bc6eaa4d00',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/de6b86ec8e1932ffeca481faa4a54cdb.vehicle',
    ),
    488 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'e72cc9403e5998c687ac7f284556cefe',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/cc1e2633ca13341aa8fdb359e3e17985.vehicle',
    ),
    489 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '8bf4a5d83aea618c5da8f15c9d705019',
      'native_key' => 'web',
      'filename' => 'modContext/6b1e3f217de404f3de4a7615ceeca852.vehicle',
    ),
    490 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '98ea8f9329b98525ba5cb9aa950ce8c7',
      'native_key' => 'mgr',
      'filename' => 'modContext/e7e42e36a951f29199e89180cff0f185.vehicle',
    ),
    491 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '4aeeea9b244955f62de40ff71daf7c78',
      'native_key' => '4aeeea9b244955f62de40ff71daf7c78',
      'filename' => 'xPDOFileVehicle/d504253ddb76f1f6a4459ddb811d3560.vehicle',
    ),
    492 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'c55d67e0cc6c4cea7bb727087a60d20f',
      'native_key' => 'c55d67e0cc6c4cea7bb727087a60d20f',
      'filename' => 'xPDOFileVehicle/8a08f541f3342d682c246fcd731afbd1.vehicle',
    ),
    493 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'b9713e4b75f0002726a9e19c2f56a125',
      'native_key' => 'b9713e4b75f0002726a9e19c2f56a125',
      'filename' => 'xPDOFileVehicle/8d181c23052237cb49741b178d66259e.vehicle',
    ),
    494 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '6938083d3e13664c24edd83fdbf9ec74',
      'native_key' => '6938083d3e13664c24edd83fdbf9ec74',
      'filename' => 'xPDOFileVehicle/33534f9cdce7ad79361e962123849771.vehicle',
    ),
  ),
);