<?php

$xpdo_meta_map = array (
  'xPDOObject' => 
  array (
    0 => 'qsbSetUserGroup',
  ),
  'xPDOSimpleObject' => 
  array (
    0 => 'qsbSet',
    1 => 'qsbButton',
    2 => 'qsbIcon',
  ),
);