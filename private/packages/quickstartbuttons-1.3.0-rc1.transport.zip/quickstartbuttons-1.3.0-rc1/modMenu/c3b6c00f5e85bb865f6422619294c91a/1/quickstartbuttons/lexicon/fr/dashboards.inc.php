<?php

$_lang['quickstartbuttons.widget'] = "Boutons d'actions rapides";
$_lang['quickstartbuttons.widget_desc'] = "Le widget des actions rapides";
