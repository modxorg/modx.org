<?php
class cbTemplate extends xPDOSimpleObject {}