<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'cbCategory',
    1 => 'cbField',
    2 => 'cbLayout',
    3 => 'cbTemplate',
    4 => 'cbDefault',
  ),
);