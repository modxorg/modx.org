<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' =>
  array (
    'readme' => 'A simple plugin that minifies the entire HTML content of rendered pages before caching. Install, and that\s it!
    
',
  ),
  'manifest-vehicles' =>
  array (
    0 =>
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e5f7225a37035a3cd9e20736560c3ec0',
      'native_key' => 'minifyhtml',
      'filename' => 'modNamespace/ea5783b1f79eabe94ae42046ac620e57.vehicle',
      'namespace' => 'minifyhtml',
    ),
    1 =>
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '879a85f3ec7dcc2f768148001b9d3f6b',
      'native_key' => 28,
      'filename' => 'modPlugin/592e837eec68b127acba85787010007f.vehicle',
      'namespace' => 'minifyhtml',
    ),
    2 =>
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '8b7bd3851dcb0268842848b3dbe6592d',
      'native_key' => 1,
      'filename' => 'modCategory/69f7c85d6a27472e5bbbc9e1f5cdbdda.vehicle',
      'namespace' => 'minifyhtml',
    ),
  ),
);
